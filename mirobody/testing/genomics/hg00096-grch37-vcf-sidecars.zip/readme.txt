Public 1000 Genomes HG00096 subset
